import unittest,copy
from reducer import reduce_test_only,REQUIRED,SET_RULE,digest
class Reducer(unittest.TestCase):
 def setUp(self):
  self.ms=[]
  for h in ['a'*64,'b'*64]:
   q12={u:{'verdict':'PASS_SCOPED_PER_UNIT_Q12','model_digest':h,'missing':[],'evidence_digest':'c'*64}for u in ['A','B']}
   self.ms.append(dict(model_digest=h,record_digest='d'*64,fresh_digest='e'*64,qualification_digest='f'*64,q12_digest=digest(q12),q12_source=q12,q12=q12,unit_ids=['A','B'],request_digest='1'*64,program_digest='2'*64,profile_digest='3'*64,quality=[dict(rule_id=k,model_hash=h,verdict='PASS'if k!=SET_RULE else'UNKNOWN',missing=[],scope='fixedsource',source_closure={'proof':True})for k in (*REQUIRED,SET_RULE)]))
  ids=sorted(m['model_digest']for m in self.ms);self.s=dict(requested_count=2,qualified_count=2,model_digests=ids,request_digest='1'*64,program_digest='2'*64,profile_digest='3'*64,pair={'pair_count':1,'model_digests':ids,'source_organization_distinct':True},member_bindings={m['model_digest']:{k:m[k]for k in ('record_digest','fresh_digest','qualification_digest','q12_digest')}for m in self.ms})
 def runcheck(self):return reduce_test_only(self.ms,self.s)
 def bad(self):self.assertEqual(self.runcheck()['verdict'],'UNKNOWN');self.assertFalse(self.runcheck()['membership_authority'])
 def test_positive_only_rule_twelve_changes(self):
  before=copy.deepcopy(self.ms);o=self.runcheck();self.assertEqual(o['verdict'],'CONTENT_VALID_NOT_AUTHORITY');self.assertFalse(o['delivery_allowed']);self.assertEqual(before,self.ms)
  for old,new in zip(self.ms,o['members']):self.assertEqual(old['quality'][:11],new['quality'][:11]);self.assertEqual(new['quality'][11]['verdict'],'PASS')
 def test_no_all12_prerequisite(self):self.assertEqual(self.ms[0]['quality'][11]['verdict'],'UNKNOWN');self.assertEqual(self.runcheck()['verdict'],'CONTENT_VALID_NOT_AUTHORITY')
 def test_stale_qualification(self):self.ms[0]['qualification_digest']='0'*64;self.bad()
 def test_crossmember(self):self.s['member_bindings'][self.ms[0]['model_digest']]['record_digest']='0'*64;self.bad()
 def test_partial_parent(self):self.ms[0]['quality'][0]['verdict']='UNKNOWN';self.bad()
 def test_partial_set(self):self.s['qualified_count']=1;self.bad()
 def test_boolean_count(self):self.s['requested_count']=True;self.bad()
 def test_pair_wrong_member(self):self.s['pair']['model_digests'][1]='0'*64;self.bad()
 def test_duplicate(self):self.ms[1]=copy.deepcopy(self.ms[0]);self.bad()
 def test_missing_unit(self):self.ms[0]['q12'].pop('B');self.bad()
 def test_q12_mutation(self):self.ms[0]['q12']['A']['missing']=['gap'];self.bad()
 def test_source_profile_mismatch(self):self.ms[0]['profile_digest']='0'*64;self.bad()
 def test_duplicate_rule(self):self.ms[0]['quality'][-1]=copy.deepcopy(self.ms[0]['quality'][0]);self.bad()
 def test_invalid_input(self):self.ms=None;self.bad()
if __name__=='__main__':unittest.main()
