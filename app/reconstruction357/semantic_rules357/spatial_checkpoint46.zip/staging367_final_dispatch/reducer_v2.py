"""Pure stage3 content reducer; never an issuer or trusted receipt API.
Production boundary must independently capture/pin the issuer and member bytes.
"""
import copy,json,hashlib
REQUIRED=('SPACE_ACCOUNTING','GUEST_ROUTE_INDEPENDENCE','LIVING_USEFUL_CONTIGUITY','CIRCULATION_NECESSITY','ROOM_PROGRAM_CAPACITY','BEDROOM_GROUPING','SERVICE_COMPACTNESS','COMMON_CORE_COMPACTNESS','PRIVACY_WITHOUT_FAKE_BAFFLE','OPENINGS_REAL','KITCHEN_PROXIMITY')
SET_RULE='DISTINCTNESS_AND_FAIRNESS'
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def hex64(x):return type(x)is str and len(x)==64 and all(c in '0123456789abcdef'for c in x)
def reduce_test_only(members,setproof):
 """The canonical contract is test-only until pinned issuer normalization exists."""
 before=digest([members,setproof]);result={'schema':'STAGE3_TEST_ONLY_CONTENT_REDUCTION','verdict':'UNKNOWN','missing':[],'members':[],'membership_authority':False,'accepted':False,'delivery_allowed':False,'release_allowed':False,'live_authority':False,'all_domain_coverage':False,'new_fresh_execution':False}
 try:
  if type(members)is not list or len(members)!=2 or any(type(x)is not dict for x in members):raise ValueError('TWO_TYPED_MEMBERS_REQUIRED')
  if type(setproof)is not dict:raise ValueError('SET_PROOF_MAPPING')
  if type(setproof.get('requested_count'))is not int or setproof['requested_count']!=2 or type(setproof.get('qualified_count'))is not int or setproof['qualified_count']!=2:raise ValueError('EXACT_REQUESTED_AND_QUALIFIED_TWO')
  ids=[x.get('model_digest')for x in members]
  if not all(hex64(x)for x in ids)or len(set(ids))!=2:raise ValueError('UNIQUE_MODEL_IDENTITIES')
  if setproof.get('model_digests')!=sorted(ids):raise ValueError('SET_MEMBERSHIP_BINDING')
  pair=setproof['pair']
  if type(pair.get('pair_count'))is not int or pair['pair_count']!=1 or pair.get('model_digests')!=sorted(ids)or pair.get('source_organization_distinct')is not True:raise ValueError('EXACT_DISTINCT_CURRENT_PAIR')
  for key in ('request_digest','program_digest','profile_digest'):
   if not hex64(setproof.get(key))or any(m.get(key)!=setproof[key]for m in members):raise ValueError('SHARED_REQUEST_PROGRAM_PROFILE:'+key)
  if type(setproof.get('member_bindings'))is not dict or set(setproof['member_bindings'])!=set(ids):raise ValueError('SET_MEMBER_BINDINGS')
  for m in members:
   mh=m['model_digest'];binding=setproof['member_bindings'][mh]
   for key in ('record_digest','fresh_digest','qualification_digest','q12_digest'):
    if not hex64(m.get(key))or binding.get(key)!=m[key]:raise ValueError('MEMBER_EVIDENCE_BINDING:'+key)
   quality=m['quality']
   if type(quality)is not list or len(quality)!=12 or any(type(q)is not dict for q in quality):raise ValueError('EXACT_QUALITY_LIST')
   qids=[q.get('rule_id')for q in quality]
   if len(set(qids))!=12 or set(qids)!=set(REQUIRED)|{SET_RULE}:raise ValueError('EXACT_RULE_INVENTORY')
   for q in quality:
    if q['rule_id'] in REQUIRED and(q.get('verdict')!='PASS'or q.get('missing')!=[]or q.get('model_hash')!=mh or not q.get('source_closure')or not q.get('scope')):raise ValueError('ELEVEN_CURRENT_SCOPED_PARENTS_REQUIRED')
   if type(m.get('unit_ids'))is not list or len(m['unit_ids'])!=2 or len(set(m['unit_ids']))!=2:raise ValueError('EXACT_UNIT_IDS')
   q12=m['q12']
   if digest(m['q12_source'])!=m['q12_digest']or set(q12)!=set(m['unit_ids']):raise ValueError('Q12_CONTENT_BINDING')
   for u in q12.values():
    if u.get('model_digest')!=mh or u.get('verdict')!='PASS_SCOPED_PER_UNIT_Q12'or u.get('missing')!=[]or not hex64(u.get('evidence_digest')):raise ValueError('INDEPENDENT_Q12_CURRENT_COMPLETE')
   rows=copy.deepcopy(quality)
   for i,q in enumerate(rows):
    if q['rule_id']==SET_RULE:rows[i]={'rule_id':SET_RULE,'model_hash':mh,'verdict':'PASS','missing':[],'codes':['TWO_FIXED_QUALIFIED_MEMBERS_AND_ACTUAL_PAIR_CONTENT_VALID'],'scope':'Content-only test of current registered request/profile/pair. Production authority requires fixed issuer boundary.','source_closure':{'set_content_digest':digest(setproof),'pair_digest':digest(pair),'member_qualification_digest':m['qualification_digest'],'independent_q12_digest':m['q12_digest'],'explicit_complete_predicate':{'requested_count_two':True,'qualified_count_two':True,'same_request_program_profile':True,'both_members_eleven_parents':True,'independent_per_unit_q12':True,'actual_distinct_pair':True}}}
   result['members'].append({'model_digest':mh,'base_qualification_digest':m['qualification_digest'],'base_quality_digest':digest(quality),'quality':rows})
  result['verdict']='CONTENT_VALID_NOT_AUTHORITY';result['set_content_digest']=digest(setproof)
 except (ValueError,KeyError,TypeError,IndexError)as e:result['missing']=[str(e)];result['members']=[]
 if before!=digest([members,setproof]):raise ValueError('INPUT_MUTATION')
 return result
