"""Preimport immutable stage3 capture, no engine/issuer/fresh execution."""
import json,hashlib,types,sys
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P.parent
BOUNDARY_SHA='1f3a339e17d3c68bb5f003e54bd3ebe6b309316ece7ee1de088cffea4b9c4fa0'
CODE_SHA='0da1fa9bbd31cb627aa8de0ad39772e682af3a9b470c485be0e821195b96a6b9'
b=(P/'boundary_v3.json').read_bytes();assert hashlib.sha256(b).hexdigest()==BOUNDARY_SHA
for n,h in json.loads(b)['files'].items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h,n
code=(P/'dispatcher_v3.py').read_bytes();assert hashlib.sha256(code).hexdigest()==CODE_SHA
if '--check' in sys.argv:print(json.dumps({'preimport_pins_verified':True,'actual_executed':False}));raise SystemExit(0)
module=types.ModuleType('_fixed_final_dispatch367');module.__file__=str(P/'dispatcher_v3.py');exec(compile(code,module.__file__,'exec'),module.__dict__)
out=module.evaluate_registered()
assert hashlib.sha256((P/'boundary_v3.json').read_bytes()).hexdigest()==BOUNDARY_SHA
assert hashlib.sha256((P/'dispatcher_v3.py').read_bytes()).hexdigest()==CODE_SHA
with (P/'actual_v3.json').open('x')as f:json.dump(out,f,indent=2)
print(json.dumps({'verdict':out['verdict'],'missing':out.get('missing',[]),'members':[{'model_digest':m['model_digest'],'rules':len(m['quality']),'passes':sum(q['verdict']=='PASS'for q in m['quality'])}for m in out.get('members',[])]}))
