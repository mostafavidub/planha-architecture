"""Stage3 fixed-source derived reviews. No caller records, receipts or proof flags.
Pending final boundary pin until the audited immutable issuer artifact exists.
"""
import json,hashlib,types,copy,os
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P.parent
BOUNDARY_SHA='1f3a339e17d3c68bb5f003e54bd3ebe6b309316ece7ee1de088cffea4b9c4fa0'
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def _capture():
 if BOUNDARY_SHA.startswith('PENDING'):raise ValueError('AUDITED_ISSUER_BOUNDARY_PENDING')
 data=(P/'boundary_v3.json').read_bytes()
 if hashlib.sha256(data).hexdigest()!=BOUNDARY_SHA:raise ValueError('BOUNDARY_CHANGED')
 cfg=json.loads(data);cap={}
 for n,h in cfg['files'].items():
  b=(ROOT/n).read_bytes()
  if hashlib.sha256(b).hexdigest()!=h:raise ValueError('FIXED_BYTES_CHANGED:'+n)
  cap[n]=b;canonical=os.path.relpath((ROOT/n).resolve(),ROOT.resolve())
  if canonical in cap and cap[canonical]!=b:raise ValueError('CONFLICTING_SOURCE_ALIAS')
  cap[canonical]=b
 return data,cfg,cap

def _load(captured,path,name):
 mod=types.ModuleType(name);mod.__file__=str(ROOT/path);exec(compile(captured[path],str(ROOT/path),'exec'),mod.__dict__);return mod

def _derive(issuer,reducer,receipt,registry,cap,pair):
 body=copy.deepcopy(receipt);stored=body.pop('immutable_set_digest')
 if digest(body)!=stored:raise ValueError('IMMUTABLE_SET_DIGEST')
 if receipt['schema']!='FIXED_TWO_MEMBER_CONCEPTUAL_SELECTED_SET367'or receipt['membership_authority']!='FIXED_PINNED_REVIEWED_CONCEPT_SET_ONLY':raise ValueError('ISSUER_SCOPE')
 if any(receipt[k]is not False for k in ('accepted','delivery_allowed','live_authority','global_domain_complete')):raise ValueError('UNSUPPORTED_ISSUER_AUTHORITY')
 if receipt['request_fulfilled_for_fixed_concept_profile']is not True:raise ValueError('FIXED_REQUEST_UNFULFILLED')
 if receipt['pair_digest']!=digest(pair)or receipt['pair_identity']!=pair['pair_identity']:raise ValueError('EXACT_PAIR_RECEIPT')
 if len(receipt['members'])!=2 or len({x['member']for x in receipt['members']})!=2:raise ValueError('ISSUER_MEMBER_INVENTORY')
 normalized=[]
 for desc in receipt['members']:
  kind=desc['member'];cfg=registry['members'][kind];r,f,q,man=[json.loads(cap[cfg[k]])for k in ('record','fresh','qualification','manifest')]
  if kind=='balanced365' and q['invocation_manifest_sha256']!=registry['sources'][cfg['manifest']]:raise ValueError('MEMBER_INVOCATION_MANIFEST')
  issuer.verify_whole_dag(kind,q,cap)
  checked=issuer.validate_member(kind,r,f,q,man)
  if checked!=desc:raise ValueError('SET_QUALIFICATION_DESCRIPTOR_MISMATCH')
  if kind=='balanced365':q12=q['internal_q12'];units=q12['evidence']
  else:q12=q['source_closures']['final_role']['internal_per_unit_review'];units=q12['units']
  normalized.append({**desc,'quality':q['quality'],'q12_source':q12,'q12':{u['unit']:{'model_digest':desc['model_digest'],'verdict':'PASS_SCOPED_PER_UNIT_Q12','missing':u['exact_pending'],'evidence_digest':digest(u)}for u in units}})
 expected={d['model_digest']:d for d in normalized}
 if len(pair['members'])!=2 or {x['model_digest']for x in pair['members']}!=set(expected):raise ValueError('PAIR_MEMBER_INVENTORY')
 for x in pair['members']:
  if x['record_digest']!=expected[x['model_digest']]['record_digest']or x['fresh_result_digest']!=expected[x['model_digest']]['fresh_digest']:raise ValueError('PAIR_MEMBER_ARTIFACT_BINDING')
 ids=sorted(expected)
 proof={'requested_count':receipt['requested_count'],'qualified_count':receipt['qualified_selected_count'],'model_digests':ids,'pair':{'pair_count':pair['pair_count'],'source_organization_distinct':pair['source_organization_distinct'],'model_digests':sorted(x['model_digest']for x in pair['members'])},'member_bindings':{m['model_digest']:{k:m[k]for k in ('record_digest','fresh_digest','qualification_digest','q12_digest')}for m in normalized},**{k:normalized[0][k]for k in ('request_digest','program_digest','profile_digest')}}
 out=reducer.reduce_test_only(normalized,proof)
 if out['verdict']!='CONTENT_VALID_NOT_AUTHORITY':raise ValueError('DERIVED_CONTENT_INVALID:'+str(out['missing']))
 out.update(schema='FIXED_TWO_MEMBER_DERIVED_SEMANTIC_REVIEW367',verdict='PASS_SCOPED_FIXED_SET_TWELVE_RULES',immutable_selected_set_digest=stored,issuer_registry_sha256=receipt['registry_sha256'],pair_digest=receipt['pair_digest'],requested_count=2,qualified_selected_count=2,scope='Only the two pinned current conceptual candidates and fixed26x28 request/sourceprofile; no fresh run, general coverage, technical approval or delivery authorization.')
 for member in out['members']:
  for row in member['quality']:
   if row['rule_id']==reducer.SET_RULE:
    row['codes']=['PINNED_QUALIFIED_SET_AND_EXACT_PAIR_JOIN'];row['scope']=out['scope'];row['source_closure'].update(immutable_selected_set_digest=stored,issuer_pair_digest=receipt['pair_digest'],issuer_registry_sha256=receipt['registry_sha256'])
 return out

def evaluate_registered():
 try:
  original,cfg,cap=_capture();issuer=_load(cap,cfg['issuer_code'],'_fixed_issuer367');reducer=_load(cap,'staging367_final_dispatch/reducer_v2.py','_fixed_stage3_reducer')
  receipt=json.loads(cap[cfg['issuer_actual']])
  registry=json.loads(cap[cfg['issuer_registry']])
  if hashlib.sha256(cap[cfg['issuer_registry']]).hexdigest()!=receipt['registry_sha256']:raise ValueError('ISSUER_REGISTRY_BINDING')
  pair=json.loads(cap[cfg['pair_actual']])
  out=_derive(issuer,reducer,receipt,registry,cap,pair)
  after,_,_=_capture()
  if after!=original:raise ValueError('POSTRUN_BOUNDARY_CHANGED')
  out['boundary_sha256']=BOUNDARY_SHA;out['issuer_rerun']=False;out['quality_rerun']=False;return out
 except (ValueError,KeyError,TypeError,IndexError,OSError,OverflowError)as e:return {'schema':'FIXED_TWO_MEMBER_DERIVED_SEMANTIC_REVIEW367','verdict':'UNKNOWN','missing':[str(e)],'members':[],'accepted':False,'delivery_allowed':False,'live_authority':False,'global_domain_complete':False,'new_fresh_execution':False}
