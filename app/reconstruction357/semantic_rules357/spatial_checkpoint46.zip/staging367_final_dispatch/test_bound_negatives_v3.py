import unittest,json,copy
import dispatcher_v3 as d
class BoundNegatives(unittest.TestCase):
 @classmethod
 def setUpClass(c):
  _,cfg,cap=d._capture();c.cfg=cfg;c.cap=cap;c.issuer=d._load(cap,cfg['issuer_code'],'_negative_issuer');c.reducer=d._load(cap,'staging367_final_dispatch/reducer_v2.py','_negative_reducer');c.receipt=json.loads(cap[cfg['issuer_actual']]);c.registry=json.loads(cap[cfg['issuer_registry']]);c.pair=json.loads(cap[cfg['pair_actual']])
 def setUp(self):self.s=copy.deepcopy(self.receipt);self.p=copy.deepcopy(self.pair);self.cap2=dict(self.cap)
 def runcheck(self):return d._derive(self.issuer,self.reducer,self.s,self.registry,self.cap2,self.p)
 def reseal(self):self.s.pop('immutable_set_digest',None);self.s['immutable_set_digest']=d.digest(self.s)
 def test_stale_qualification_descriptor(self):self.s['members'][0]['qualification_digest']='0'*64;self.reseal();self.assertRaises(ValueError,self.runcheck)
 def test_crossmember_fresh(self):self.s['members'][0]['fresh_digest']=self.s['members'][1]['fresh_digest'];self.reseal();self.assertRaises(ValueError,self.runcheck)
 def test_partial_set(self):self.s['qualified_selected_count']=1;self.reseal();self.assertRaises(ValueError,self.runcheck)
 def test_tampered_immutable(self):self.s['requested_count']=1;self.assertRaises(ValueError,self.runcheck)
 def test_stale_pair(self):self.p['members'][0]['fresh_result_digest']='0'*64;self.assertRaises(ValueError,self.runcheck)
 def test_partial_actual_parent(self):
  cfg=self.registry['members']['joint367'];q=json.loads(self.cap2[cfg['qualification']]);q['quality'][0]['verdict']='UNKNOWN';self.cap2[cfg['qualification']]=json.dumps(q).encode();self.assertRaises(ValueError,self.runcheck)
 def test_partial_q12(self):
  cfg=self.registry['members']['joint367'];q=json.loads(self.cap2[cfg['qualification']]);q['source_closures']['final_role']['internal_per_unit_review']['units'][0]['exact_pending']=['gap'];self.cap2[cfg['qualification']]=json.dumps(q).encode();self.assertRaises(ValueError,self.runcheck)
if __name__=='__main__':unittest.main()
